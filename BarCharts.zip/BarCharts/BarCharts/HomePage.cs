﻿using System;
using Xamarin.Forms;
using System.Collections.Generic;
using System.Threading;
using System.Runtime.InteropServices;

namespace BarCharts
{
    public class HomePage:ContentPage
    {
        public HomePage()
        {
           
            this.Title = "Barchart Demo";
            Padding = 5;
            BackgroundColor = Color.White;
        }

        protected override void OnAppearing()
        {            
            base.OnAppearing();
            
            var Bars = new List<BarItem>();
           
            var chart = new BarChart
            {
                ChartName = "Year in Review",
                Bars = Bars,
                Format = "{0:C1}",
                Footer = "* Total Revenue Generated",
                    
            };
            
            Bars.Add(new BarItem
                {
                    BarValue = App.GetRandomNumber(25, 100),
                    BarTitle = "January",
                });
            Bars.Add(new BarItem
                {
                    BarTitle = "February",
                    BarValue = App.GetRandomNumber(50, 100),
                });
            Bars.Add(new BarItem
                {
                    BarTitle = "March",
                    BarValue = App.GetRandomNumber(40, 100),
                });
            Bars.Add(new BarItem
                {
                    BarTitle = "April",
                    BarValue = App.GetRandomNumber(50, 100),
                });
            Bars.Add(new BarItem
                {
                    BarTitle = "May",
                    BarValue = App.GetRandomNumber(30, 100),
                        
                });
            Bars.Add(new BarItem
                {
                    BarTitle = "June",
                    BarValue = App.GetRandomNumber(40, 100),

                });
            Bars.Add(new BarItem
                {
                    BarTitle = "July",
                    BarValue = App.GetRandomNumber(33, 100),

                });
            Bars.Add(new BarItem
                {
                    BarTitle = "August",
                    BarValue = App.GetRandomNumber(40, 100),

                });
            Bars.Add(new BarItem
                {
                    BarTitle = "September",
                    BarValue = App.GetRandomNumber(25, 100),

                });
            Bars.Add(new BarItem
                {
                    BarTitle = "October",
                    BarValue = App.GetRandomNumber(40, 100),

                });
            Bars.Add(new BarItem
                {
                    BarTitle = "November",
                    BarValue = App.GetRandomNumber(30, 100),

                });
            Bars.Add(new BarItem
                {
                    BarTitle = "December",
                    BarValue = App.GetRandomNumber(20, 100),

                });
            var pageScroll = new ScrollView
            {
                HorizontalOptions = LayoutOptions.FillAndExpand,
                VerticalOptions = LayoutOptions.FillAndExpand,
                Padding = 0,
            };
            var pageStack = new StackLayout
            {
                HorizontalOptions = LayoutOptions.FillAndExpand,
                VerticalOptions = LayoutOptions.FillAndExpand,
                Padding = 0,
                Spacing = 10,
            };
            pageScroll.Content = pageStack;
            pageStack.Children.Add(new BarChartView(chart, this));
            pageStack.Children.Add(new BarChartView(chart, this));
            this.Content = pageScroll;
        }

       
    }
}

