﻿using System;
using Xamarin.Forms;

using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;

namespace BarCharts
{
    public class BarItem
    {
        public string BarTitle{ get; set; }

        public double BarValue{ get; set; }

        public string BarColor{ get; set; }
    }

    public class BarChart
    {
        public string ChartName{ get; set; }

        public string Format{ get; set; }

        public List<BarItem>Bars{ get; set; }

        public string Footer{ get; set; }
    }

    public class BarChartView:StackLayout
    {
       
        public class ChartView:AbsoluteLayout
        {
            public int RowHeight = 20;
            public double GridWidth = 0;
            public double GridHeight = 0;
            public int Columns = 5;
            public int Rows = 0;
            public double ColumnWidth = 0;
            public int CurrentRow = 0;
            private BarChart _series;
            public double Unit = 0;
            public double fontSize = 9;

            public double HundredPercentValue{ get; set; }

            public void Hline(int row, BarChart series)
            {
                this.Children.Add(new BoxView{ HeightRequest = .5, WidthRequest = GridWidth, BackgroundColor = (row == 1) ? Color.Gray.WithLuminosity(.7) : Color.Gray.WithLuminosity(.9) }, new Rectangle(0, row * RowHeight, GridWidth, .5), AbsoluteLayoutFlags.None);
                string legend = String.Empty;
                if (row < Rows)
                {
                    if (row > 0)
                    {
                        legend = _series.Bars[row - 1].BarTitle.Trim();
                    }
                    else
                    {
                        
                        legend = String.Format(series.Format, 0);
                    }
                    this.Children.Add(new Label
                        { 
                            Text = legend, 
                            HorizontalTextAlignment = TextAlignment.End, 
                            VerticalTextAlignment = TextAlignment.Center, 
                            WidthRequest = ColumnWidth - 2,
                            HeightRequest = RowHeight,
                            FontSize = fontSize,
                            FontAttributes = FontAttributes.Bold,
                            TextColor = Color.Gray.WithLuminosity(.4),
                            LineBreakMode = LineBreakMode.TailTruncation,
                        }, new Rectangle(0, row * RowHeight, ColumnWidth - 2, RowHeight), AbsoluteLayoutFlags.None);     


                    CurrentRow = row;
                }
            }

            public void Vline(int column)
            {
                this.Children.Add(new BoxView{ HeightRequest = GridHeight, WidthRequest = .5, BackgroundColor = (column == 1) ? Color.Gray.WithLuminosity(.7) : Color.Gray.WithLuminosity(.9) }, new Rectangle(ColumnWidth * column, 0, .5, GridHeight), AbsoluteLayoutFlags.None);

            }

         

            public Color RandomColor()
            {
                List<int> numbers = new List<int>();
                for (int i = 30; i < 128; i++)
                {
                    numbers.Add(i + 127);
                }
                return Color.FromRgb(numbers.OrderBy(x => Guid.NewGuid()).FirstOrDefault(), numbers.OrderBy(x => Guid.NewGuid()).FirstOrDefault(), numbers.OrderBy(x => Guid.NewGuid()).FirstOrDefault());
            }

            public int RoundValueToNearst100(double value, int nearest = 100)
            {
                
                int result = (int)Math.Ceiling(value / nearest);
                if (value > 0 && result == 0)
                {
                    result = 1;
                }
                return (int)result * nearest;
            }


            public ChartView(BarChart series, ContentPage parentPage)
            {
                _series = series;
                this.Padding = 0;
                this.BackgroundColor = Color.Gray.WithLuminosity(.99);

                if (parentPage.Height > parentPage.Width)
                {
                    Columns = 5;
                }
                else
                {
                    Columns = 11;
                }
               
                this.GridWidth = (parentPage.Width - parentPage.Padding.HorizontalThickness) - Device.OnPlatform(2, 2, 2);
                this.Rows = series.Bars.Count + 1;
                this.GridHeight = this.Rows * RowHeight;
                this.WidthRequest = this.GridWidth;
                this.HeightRequest = this.HeightRequest;

                double max = Math.Ceiling(series.Bars.ToArray<BarItem>().Max(t => t.BarValue));
                if (max <= 100)
                {
                    this.HundredPercentValue = RoundValueToNearst100(max, 100);
                }
                else if (max > 100 && max <= 1000)
                {
                    this.HundredPercentValue = RoundValueToNearst100(max, 1000);
                }
                else if (max > 1000 && max <= 10000)
                {
                    this.HundredPercentValue = RoundValueToNearst100(max, 1000);
                }
                else if ((max > 10000 && max <= 10000))
                {
                    this.HundredPercentValue = RoundValueToNearst100(max, 10000);
                }
                else if ((max > 10000 && max <= 100000))
                {
                    this.HundredPercentValue = RoundValueToNearst100(max, 100000);
                }
                else if ((max > 100000 && max <= 1000000))
                {
                    this.HundredPercentValue = RoundValueToNearst100(max, 100000);
                }

               
                ColumnWidth = GridWidth / Columns;
                this.Unit = (GridWidth - ColumnWidth) / HundredPercentValue;
                for (int i = 0; i < Rows + 1; i++)
                {
                    Hline(i, series);
                }

                for (int i = 0; i < Columns + 1; i++)
                {
                    Vline(i);
                    if (i > 0 && i < Columns)
                    {
                        string header = string.Empty;
                        if (Columns == 5)
                        {
                            
                          
                            header = String.Format(series.Format, Math.Round((HundredPercentValue / 4) * i, 0));
                        }
                        else
                        {
                            header = String.Format(series.Format, Math.Round((HundredPercentValue / 10) * i, 0));
                            
                        }

                        this.Children.Add(new Label
                            {
                                Text = header,
                                HorizontalTextAlignment = TextAlignment.End,
                                VerticalTextAlignment = TextAlignment.Center,
                                HeightRequest = RowHeight,
                                WidthRequest = ColumnWidth - 3,
                                FontSize = fontSize,
                                TextColor = Color.Gray.WithLuminosity(.4),
                                LineBreakMode = LineBreakMode.TailTruncation,
                                FontAttributes = FontAttributes.Bold,

                            }, new Rectangle(ColumnWidth * i, 0, ColumnWidth - 2, RowHeight), AbsoluteLayoutFlags.None);
                    }

                }
                for (int i = 0; i < series.Bars.Count; i++)
                {
                    var barColor = RandomColor();
                    var barBorder = new StackLayout
                    {
                        HeightRequest = RowHeight - 2,
                        BackgroundColor = barColor,
                        Opacity = .3,
                        HorizontalOptions = LayoutOptions.FillAndExpand,
                        VerticalOptions = LayoutOptions.FillAndExpand,
                        WidthRequest = _series.Bars[i].BarValue * Unit,

                    };
                    
                    var bar = new StackLayout
                    {
                        HeightRequest = RowHeight - 4,
                        BackgroundColor = barColor.WithLuminosity(.4),
                        Opacity = .3,
                        HorizontalOptions = LayoutOptions.FillAndExpand,
                        VerticalOptions = LayoutOptions.FillAndExpand,
                        WidthRequest = _series.Bars[i].BarValue * Unit //- .5,

                    };
                    var label = new Label
                    {
                        HeightRequest = RowHeight - 2,
                        BackgroundColor = Color.Transparent,

                        HorizontalOptions = LayoutOptions.FillAndExpand,
                        VerticalOptions = LayoutOptions.FillAndExpand,
                        VerticalTextAlignment = TextAlignment.Center,
                        HorizontalTextAlignment = TextAlignment.End,
                        FontSize = fontSize,
                        WidthRequest = bar.WidthRequest - 2,
                        TextColor = Color.Gray.WithLuminosity(.3),
                        Text = (Math.Abs(_series.Bars[i].BarValue) > .001) ? string.Format(series.Format, _series.Bars[i].BarValue) : string.Format(series.Format, .0),
                        LineBreakMode = LineBreakMode.TailTruncation,

                    };
                    this.Children.Add(barBorder, new Rectangle(ColumnWidth, ((i + 1) * RowHeight) + 1.5, bar.WidthRequest, RowHeight - 2), AbsoluteLayoutFlags.None);
                    this.Children.Add(bar, new Rectangle(ColumnWidth + 1, ((i + 1) * RowHeight) + 2, bar.WidthRequest - 2, RowHeight - 4), AbsoluteLayoutFlags.None);
                    this.Children.Add(label, new Rectangle(ColumnWidth, ((i + 1) * RowHeight) + 1, label.WidthRequest, RowHeight), AbsoluteLayoutFlags.None);
                }
            }
        }

        public ChartView Chart{ get; set; }

         
        public BarChartView(BarChart series, ContentPage parentPage)
        {
            this.BackgroundColor = Color.White;
            this.Spacing = 0;
            this.Padding = .5;
            var total = series.Bars.ToArray<BarItem>().Sum(t => t.BarValue);

            Label totalLabel = new Label
            {
                Text = series.Footer + " - " + string.Format(series.Format, total),
                HorizontalOptions = LayoutOptions.CenterAndExpand,
                VerticalOptions = LayoutOptions.Center,
                HeightRequest = 20,
                VerticalTextAlignment = TextAlignment.Center,
                HorizontalTextAlignment = TextAlignment.Center,
                FontSize = 14,
                BackgroundColor = Color.Transparent,
                TextColor = Color.Gray.WithLuminosity(.5),
                LineBreakMode = LineBreakMode.TailTruncation,

            };
            Chart = new ChartView(series, parentPage);

            this.Children.Add(Chart);
            this.Children.Add(totalLabel);
            parentPage.SizeChanged += ((object sender, EventArgs e) =>
            {
                this.Children.Remove(totalLabel);
                this.Children.Remove(Chart);

                Chart = new ChartView(series, parentPage);

                this.Children.Add(Chart);
                this.Children.Add(totalLabel);

            });

        }


         
    }

    
}

